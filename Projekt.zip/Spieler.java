package Projekt_Quiz;

/**
 * Die Klasse Spieler repräsentiert einen einzelnen Spieler im Quizspiel.
 * Sie speichert den Namen, die Anzahl der Leben, die benötigte Zeit und ob der Spieler noch aktiv am Spiel teilnimmt.
 */
public class Spieler {
    // Der Name des Spielers.
    private String name;

    // Die aktuelle Anzahl der Leben des Spielers.
    private int leben;

    // Die bisher benötigte Zeit des Spielers in Millisekunden.
    private long zeit; // Zeit in Millisekunden

    // Gibt an, ob der Spieler noch im Spiel ist.
    private boolean nochImSpiel = true;

    /**
     * Konstruktor zum Erstellen eines neuen Spielers.
     * Standardmäßig startet der Spieler mit 3 Leben.
     * @param name Der Name des Spielers.
     */
    public Spieler(String name) {
        this.name = name;
        this.leben = 3;
    }

    /**
     * Gibt den Namen des Spielers zurück.
     * @return Der Name des Spielers.
     */
    public String getName() {
        return name;
    }

    /**
     * Gibt die aktuelle Anzahl der Leben des Spielers zurück.
     * @return Die Anzahl der Leben.
     */
    public int getLeben() {
        return leben;
    }

    /**
     * Verringert die Anzahl der Leben des Spielers um den angegebenen Wert.
     * Falls die Leben auf 0 oder weniger fallen, wird der Spieler als ausgeschieden markiert.
     * @param anzahl Die Anzahl der Leben, die abgezogen werden sollen.
     */
    public void verliereLeben(int anzahl) {
        leben -= anzahl;
        if (leben <= 0) {
            leben = 0;
            nochImSpiel = false;
        }
    }

    /**
     * Überprüft, ob der Spieler noch im Spiel ist.
     * Ein Spieler ist im Spiel, wenn nochImSpiel true ist und die Leben größer als 0 sind.
     * @return true, wenn der Spieler noch im Spiel ist, sonst false.
     */
    public boolean istNochImSpiel() {
        return nochImSpiel && leben > 0;
    }

    /**
     * Gibt die bisher benötigte Zeit des Spielers zurück.
     * @return Die Zeit in Millisekunden.
     */
    public long getZeit() {
        return zeit;
    }

    /**
     * Setzt die bisher benötigte Zeit des Spielers.
     * @param zeit Die Zeit in Millisekunden.
     */
    public void setZeit(long zeit) {
        this.zeit = zeit;
    }
}