package Projekt_Quiz;

import javax.swing.*;
import java.io.*;
import java.net.*;
import java.util.*;

/**
 * Der QuizServer übernimmt die Steuerung des gesamten Spiels.
 * Er nimmt Client-Verbindungen entgegen, startet das Spiel, verwaltet Spieler,
 * koordiniert Nachrichten und erstellt die Rangliste.
 */
public class QuizServer {
    private ServerSocket serverSocket;                     // Server-Socket zum Warten auf eingehende Verbindungen
    private List<ClientHandler> clients = new ArrayList<>(); // Liste aller verbundenen Clients
    private boolean spielGestartet = false;                // Gibt an, ob das Spiel bereits gestartet wurde
    private List<Spieler> spielerListe = new ArrayList<>(); // Liste aller Spieler (inkl. Host)
    private int schwierigkeitsgrad;                        // Schwierigkeitsgrad des Spiels
    private String hostName;                               // Name des Hosts (lokaler Spieler)
    private QuizSpielGUI hostGUI;                          // GUI des Hosts

    // Map zum Speichern der benötigten Zeiten für das Quiz je Spieler
    private final Map<String, Long> fertigeSpieler = new HashMap<>();

    // Statische Referenz auf den aktuell laufenden Server (z. B. für GUI-Zugriffe)
    private static QuizServer laufenderServer = null;

    /**
     * Startet den Server auf dem gegebenen Port mit Spielername und Schwierigkeitsgrad.
     */
    public void start(int port, int schwierigkeitsgrad, String hostName) throws IOException {
        this.schwierigkeitsgrad = schwierigkeitsgrad;
        this.hostName = hostName;
        laufenderServer = this;

        try {
            serverSocket = new ServerSocket(port);
            System.out.println("=== SERVER ERFOLGREICH GESTARTET ===");
            System.out.println("Port: " + port);
            System.out.println("Host: " + hostName);
            System.out.println("Schwierigkeitsgrad: " + schwierigkeitsgrad);
            System.out.println("Warte auf Verbindungen...");
            System.out.println("=====================================");

            // Erstelle Host-Spielerobjekt und füge es der Liste hinzu
            Spieler host = new Spieler(hostName);
            spielerListe.add(host);

            // Solange das Spiel nicht gestartet wurde, warte auf Clients
            while (!spielGestartet) {
                try {
                    System.out.println("Warte auf Client-Verbindung...");
                    Socket clientSocket = serverSocket.accept(); // Warten auf neue Verbindung
                    System.out.println("NEUER CLIENT VERBUNDEN!");
                    System.out.println("Client IP: " + clientSocket.getInetAddress().getHostAddress());

                    // Erstelle einen neuen Handler für den Client
                    ClientHandler clientHandler = new ClientHandler(clientSocket, this);
                    clients.add(clientHandler);
                    new Thread(clientHandler).start(); // Starte neuen Thread für den Client

                    System.out.println("Anzahl verbundene Clients: " + clients.size());

                    // Starte das Spiel, wenn ein Client verbunden ist (Host + Client = 2 Spieler)
                    if (clients.size() == 1 && !spielGestartet) {
                        spielGestartet = true;
                        System.out.println("SPIEL WIRD GESTARTET - 2 Spieler verbunden!");

                        // Füge Client als Spieler hinzu
                        Spieler client = new Spieler("Client");
                        spielerListe.add(client);

                        // Starte die GUI für den Host im Event-Dispatch-Thread (Swing)
                        SwingUtilities.invokeLater(() -> {
                            System.out.println("Erstelle Host-GUI...");
                            hostGUI = new QuizSpielGUI(host, schwierigkeitsgrad, new ArrayList<>(spielerListe), null);
                        });

                        // Kurze Wartezeit, bevor der Start-Broadcast kommt
                        Thread.sleep(1000);

                        // Sende Startsignal mit Spielerliste an alle Clients
                        broadcast("SPIEL_STARTET", spielerListeToString(spielerListe));

                        System.out.println("=== SPIEL ERFOLGREICH GESTARTET ===");
                        System.out.println("Spieler: " + spielerListe.size());
                        for (Spieler spieler : spielerListe) {
                            System.out.println("- " + spieler.getName());
                        }
                        System.out.println("===================================");
                    }
                } catch (IOException e) {
                    if (!serverSocket.isClosed()) {
                        System.err.println("Fehler beim Akzeptieren einer Client-Verbindung: " + e.getMessage());
                        e.printStackTrace();
                    }
                    break; // Beende Schleife bei Fehler
                } catch (InterruptedException e) {
                    System.err.println("Thread unterbrochen: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            // Fehler beim Starten des Servers
            System.err.println("FEHLER beim Starten des Servers auf Port " + port);
            System.err.println("Mögliche Ursachen:");
            System.err.println("- Port bereits in Verwendung");
            System.err.println("- Keine Berechtigung für Port");
            System.err.println("- Firewall blockiert Port");
            throw e;
        }
    }

    /**
     * Broadcast-Methode: Sende Nachricht an alle verbundenen Clients (inkl. optionaler Spielerliste).
     */
    public synchronized void broadcast(String message, String spielerListe) {
        String fullMessage = message + (spielerListe != null ? "|" + spielerListe : "");
        System.out.println("Broadcasting: " + fullMessage);

        for (ClientHandler client : clients) {
            try {
                client.sendMessage(fullMessage);
            } catch (Exception e) {
                System.err.println("Fehler beim Senden an Client: " + e.getMessage());
            }
        }
    }

    /**
     * Überladene Broadcast-Methode ohne Spielerliste.
     */
    public void broadcast(String message) {
        broadcast(message, null);
    }

    /**
     * Entfernt einen Client aus der Clientliste.
     */
    public synchronized void removeClient(ClientHandler client) {
        clients.remove(client);
        System.out.println("Client entfernt. Verbleibende Clients: " + clients.size());
    }

    /**
     * Wandelt die Spielerliste in einen String um (durch Kommas getrennt).
     */
    private String spielerListeToString(List<Spieler> spielerListe) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < spielerListe.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(spielerListe.get(i).getName());
        }
        return sb.toString();
    }

    /**
     * Stoppt den Server, indem der Socket geschlossen wird.
     */
    public void stop() throws IOException {
        if (serverSocket != null && !serverSocket.isClosed()) {
            serverSocket.close();
        }
    }

    /**
     * Wird aufgerufen, wenn ein Spieler das Spiel beendet hat.
     * Speichert die Zeit und sendet ggf. die finale Rangliste.
     */
    public synchronized void spielerFertig(String name, long zeit) {
        fertigeSpieler.put(name, zeit);
        broadcastRangliste();

        // Wenn alle Spieler fertig sind, sende finale Rangliste
        if (fertigeSpieler.size() == spielerListe.size()) {
            broadcast("RANGLISTE_FINAL|" + getFinalRanking());
            // Highscore speichern (lokal auf dem Host)
            Highscore.speichereAlle(fertigeSpieler);
        }
    }

    /**
     * Sende aktuelle Zwischen-Rangliste an alle Clients.
     */
    private void broadcastRangliste() {
        List<Map.Entry<String, Long>> liste = new ArrayList<>(fertigeSpieler.entrySet());
        liste.sort(Comparator.comparingLong(Map.Entry::getValue)); // Sortiere nach Zeit

        StringBuilder b = new StringBuilder("RANGLISTE|");
        for (int i = 0; i < liste.size(); i++) {
            if (i > 0) b.append(";");
            b.append(liste.get(i).getKey()).append(",").append(liste.get(i).getValue());
        }

        for (ClientHandler client : clients) {
            client.sendMessage(b.toString());
        }
    }

    /**
     * Gibt die finale Rangliste als String zurück (für "RANGLISTE_FINAL").
     */
    private String getFinalRanking() {
        List<Map.Entry<String, Long>> liste = new ArrayList<>(fertigeSpieler.entrySet());
        liste.sort(Comparator.comparingLong(Map.Entry::getValue)); // Sortiere nach Zeit

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < liste.size(); i++) {
            if (i > 0) sb.append(";");
            sb.append(liste.get(i).getKey()).append(",").append(liste.get(i).getValue());
        }
        return sb.toString();
    }

    /**
     * Statische Hilfsmethode zum Melden der Zeit vom Host (GUI).
     */
    public static void meldeHostFertig(String name, long zeit) {
        if (laufenderServer != null) {
            laufenderServer.spielerFertig(name, zeit);
        }
    }
}