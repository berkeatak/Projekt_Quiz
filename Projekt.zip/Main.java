package Projekt_Quiz;

import javax.swing.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Hauptklasse des Quiz-Projekts.
 * Verwaltet die zentrale Steuerung des Programms,
 * wie das Hauptmenü, die Modus-Auswahl und das Starten
 * von Einzel- oder Mehrspielerpartien.
 */
public class Main {
    // Speichern der zuletzt gewählten Einstellungen, um einen Neustart zu ermöglichen
    private static int letzterModus = -1; // 0 = Einzelspieler, 1 = Mehrspieler
    private static int letzterSchwierigkeitsgrad = -1;
    private static String letzterName = null;
    private static String letzterServerAddress = null;

    /**
     * Einstiegspunkt des Programms.
     * Startet das Hauptmenü im Event-Dispatch-Thread von Swing.
     */
    public static void main(String[] args) {
        // GUI möglichst thread-sicher starten (Swing-Konvention)
        SwingUtilities.invokeLater(Main::showMainMenu);
    }

    /**
     * Zeigt das Hauptmenü an, in dem der Benutzer zwischen Einzel- und Mehrspieler wählen kann.
     * Bei Abbruch wird das Programm beendet.
     */
    public static void showMainMenu() {
        // Dialog zur Modus-Auswahl (Einzel/Mehrspieler)
        ModusAuswahlDialog dialog = new ModusAuswahlDialog(null);
        dialog.setVisible(true);

        int modusAuswahl = dialog.gewaehlterModus;
        if (modusAuswahl == 0) {
            // Einzelspieler-Modus starten
            letzterModus = 0;
            einzelspielerModus();
        } else if (modusAuswahl == 1) {
            // Mehrspieler-Modus starten
            letzterModus = 1;
            mehrspielerModus();
        } else {
            // Dialog abgebrochen oder geschlossen: Programm beenden
            System.exit(0);
        }
    }

    /**
     * Startet den zuletzt gespielten Modus mit den letzten Einstellungen neu.
     * Falls kein Modus bekannt ist, kehrt zum Hauptmenü zurück.
     */
    public static void restartLastMode() {
        if (letzterModus == 0) {
            einzelspielerModus(true);
        } else if (letzterModus == 1) {
            mehrspielerModus(true);
        } else {
            showMainMenu();
        }
    }

    /**
     * Startet den Einzelspielermodus (mit Abfrage nach Schwierigkeitsgrad und Name).
     */
    private static void einzelspielerModus() {
        einzelspielerModus(false);
    }

    /**
     * Startet den Einzelspielermodus.
     * @param wiederholung Gibt an, ob die zuletzt gewählten Einstellungen wiederverwendet werden sollen.
     */
    private static void einzelspielerModus(boolean wiederholung) {
        if (!wiederholung) {
            // Schwierigkeitsgrad abfragen
            letzterSchwierigkeitsgrad = waehleSchwierigkeitsgrad();
            if (letzterSchwierigkeitsgrad == -1) {
                showMainMenu();
                return;
            }

            // Spielername abfragen
            letzterName = waehleName();
            if (letzterName == null || letzterName.isEmpty()) letzterName = "Spieler";
        }
        // Spieler-Objekt und Liste anlegen (für Kompatibilität mit Mehrspieler)
        Spieler spieler = new Spieler(letzterName);
        List<Spieler> spielerListe = new ArrayList<>();
        spielerListe.add(spieler);

        // Quiz-GUI für Einzelspieler starten
        new QuizSpielGUI(spieler, letzterSchwierigkeitsgrad, spielerListe, null);
    }

    /**
     * Startet den Mehrspielermodus (mit Abfrage, ob Host oder Client).
     */
    private static void mehrspielerModus() {
        mehrspielerModus(false);
    }

    /**
     * Startet den Mehrspielermodus.
     * @param wiederholung Gibt an, ob die zuletzt gewählten Einstellungen wiederverwendet werden sollen.
     */
    private static void mehrspielerModus(boolean wiederholung) {
        if (!wiederholung) {
            // Dialog: Host (Raum erstellen) oder Client (Raum beitreten)?
            MehrspielerAuswahlDialog mehrDialog = new MehrspielerAuswahlDialog(null);
            mehrDialog.setVisible(true);
            int mehrspielerAuswahl = mehrDialog.auswahl;
            // Abbrechen oder zurück: zurück zum Hauptmenü
            if (mehrspielerAuswahl == 2 || mehrspielerAuswahl == -1) {
                showMainMenu();
                return;
            }

            // Schwierigkeitsgrad abfragen
            letzterSchwierigkeitsgrad = waehleSchwierigkeitsgrad();
            if (letzterSchwierigkeitsgrad == -1) {
                showMainMenu();
                return;
            }

            if (mehrspielerAuswahl == 0) { // Raum erstellen (Server)
                letzterName = waehleName();
                if (letzterName == null || letzterName.isEmpty()) letzterName = "Host";
                final String finalHostName = letzterName;

                // Lokale IP-Adresse für den Mitspieler anzeigen
                String ipAddress = getLocalIPAddress();
                String serverInfo = "Server wird gestartet...\n" +
                        "Port: 6666\n" +
                        "Deine IP-Adresse: " + ipAddress + "\n\n" +
                        "Teile diese IP-Adresse mit dem anderen Spieler!\n" +
                        "Warte auf zweiten Spieler...";
                JOptionPane.showMessageDialog(null, serverInfo, "Server Info", JOptionPane.INFORMATION_MESSAGE);

                // Server-Thread starten, damit GUI nicht blockiert
                QuizServer server = new QuizServer();
                new Thread(() -> {
                    try {
                        server.start(6666, letzterSchwierigkeitsgrad, finalHostName);
                    } catch (IOException e) {
                        e.printStackTrace();
                        // Fehlermeldung im GUI-Thread anzeigen
                        SwingUtilities.invokeLater(() ->
                                JOptionPane.showMessageDialog(null, "Fehler beim Starten des Servers: " + e.getMessage())
                        );
                    }
                }).start();
            } else if (mehrspielerAuswahl == 1) { // Raum beitreten (Client)
                // Server-Adresse abfragen
                ServerAdresseDialog serverDialog = new ServerAdresseDialog(null);
                serverDialog.setVisible(true);
                letzterServerAddress = serverDialog.serverAdresse;
                if (letzterServerAddress == null || letzterServerAddress.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Keine Server-Adresse eingegeben!");
                    showMainMenu();
                    return;
                }
                // Name abfragen
                letzterName = waehleName();
                if (letzterName == null || letzterName.isEmpty()) letzterName = "Client";
                final String finalServerAddress = letzterServerAddress.trim();
                final String finalClientName = letzterName;

                // Verbindung zum Server anzeigen
                JOptionPane.showMessageDialog(null, "Verbinde zum Server: " + finalServerAddress + ":6666\n\nBitte warten...");
                // Verbindung zum Server in extra Thread aufbauen
                new Thread(() -> {
                    try {
                        QuizClient client = new QuizClient(finalServerAddress, 6666);
                        client.startConnection(letzterSchwierigkeitsgrad, finalClientName);
                    } catch (IOException e) {
                        e.printStackTrace();
                        // Fehler im GUI anzeigen
                        SwingUtilities.invokeLater(() ->
                                JOptionPane.showMessageDialog(null,
                                        "Fehler beim Verbinden zum Server!\n\n" +
                                                "Technischer Fehler: " + e.getMessage())
                        );
                    }
                }).start();
            }
        } else {
            // Wiederholung: Letzte Einstellungen verwenden
            if (letzterServerAddress == null || letzterName == null || letzterSchwierigkeitsgrad == -1) {
                showMainMenu();
                return;
            }
            if (letzterModus == 1 && letzterServerAddress != null) {
                String finalServerAddress = letzterServerAddress;
                String finalClientName = letzterName;
                new Thread(() -> {
                    try {
                        QuizClient client = new QuizClient(finalServerAddress, 6666);
                        client.startConnection(letzterSchwierigkeitsgrad, finalClientName);
                    } catch (IOException e) {
                        e.printStackTrace();
                        SwingUtilities.invokeLater(() ->
                                JOptionPane.showMessageDialog(null,
                                        "Fehler beim Verbinden zum Server!\n\n" +
                                                "Technischer Fehler: " + e.getMessage())
                        );
                    }
                }).start();
            }
        }
    }

    /**
     * Öffnet einen Dialog zur Auswahl des Schwierigkeitsgrads.
     * @return Schwierigkeitsgrad (0 = leicht, 1 = mittel, 2 = schwer), oder -1 bei Abbruch
     */
    public static int waehleSchwierigkeitsgrad() {
        SchwierigkeitsgradDialog schwierigDialog = new SchwierigkeitsgradDialog(null);
        schwierigDialog.setVisible(true);
        return schwierigDialog.schwierigkeitsgrad;
    }

    /**
     * Öffnet einen Dialog für die Namen-Eingabe.
     * @return Eingegebener Name, oder null bei Abbruch
     */
    public static String waehleName() {
        NameEingabeDialog nameDialog = new NameEingabeDialog(null);
        nameDialog.setVisible(true);
        return nameDialog.spielerName;
    }

    /**
     * Ermittelt die lokale IP-Adresse des Computers.
     * @return IP-Adresse als String, oder eine Fehlermeldung.
     */
    private static String getLocalIPAddress() {
        try {
            java.net.InetAddress localHost = java.net.InetAddress.getLocalHost();
            return localHost.getHostAddress();
        } catch (Exception e) {
            return "IP nicht ermittelbar - verwende ipconfig in cmd";
        }
    }
}