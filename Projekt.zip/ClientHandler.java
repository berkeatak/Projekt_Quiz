package Projekt_Quiz;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

/**
 * Diese Klasse repräsentiert einen einzelnen verbundenen Client auf dem QuizServer.
 * Sie wird in einem eigenen Thread ausgeführt und übernimmt das Empfangen und Senden von Nachrichten.
 */
class ClientHandler implements Runnable {
    private Socket clientSocket;           // Socket-Verbindung zum Client
    private QuizServer server;             // Referenz auf den Hauptserver zur Kommunikation mit anderen Clients
    private PrintWriter out;               // Zum Senden von Nachrichten an den Client
    private BufferedReader in;             // Zum Empfangen von Nachrichten vom Client
    private String clientIP;               // IP-Adresse des verbundenen Clients (zur Protokollierung)

    /**
     * Konstruktor – Initialisiert den Handler mit dem Client-Socket und dem Server.
     */
    public ClientHandler(Socket socket, QuizServer server) {
        this.clientSocket = socket;
        this.server = server;
        this.clientIP = socket.getInetAddress().getHostAddress(); // Speichert die IP-Adresse des Clients
    }

    /**
     * Wird beim Starten des Threads aufgerufen. Übernimmt die Kommunikation mit dem Client.
     */
    @Override
    public void run() {
        try {
            System.out.println("=== CLIENT HANDLER GESTARTET ===");
            System.out.println("Client IP: " + clientIP);

            // Ein- und Ausgabeströme für die Kommunikation mit dem Client initialisieren
            out = new PrintWriter(clientSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

            System.out.println("Client Handler bereit für: " + clientIP);

            String inputLine;
            // Nachrichten vom Client lesen, bis die Verbindung getrennt wird
            while ((inputLine = in.readLine()) != null) {
                System.out.println("Empfangen von " + clientIP + ": " + inputLine);

                // Spezialfall: Der Client hat das Quiz beendet und sendet Zeit
                if (inputLine.startsWith("FINISHED|")) {
                    String[] split = inputLine.split("\\|"); // Erwartet: FINISHED|Name|Zeit
                    String name = split[1];
                    long zeit = Long.parseLong(split[2]);
                    server.spielerFertig(name, zeit); // Meldet dem Server die Endzeit des Spielers
                } else {
                    // Alle anderen Nachrichten werden an alle Clients weitergeleitet
                    server.broadcast("CLIENT_MESSAGE|" + clientIP + "|" + inputLine);
                }
            }

        } catch (IOException e) {
            // Fehlerbehandlung bei Verbindungsproblemen
            System.err.println("Client Handler Fehler für " + clientIP + ": " + e.getMessage());
            if (!clientSocket.isClosed()) {
                e.printStackTrace();
            }
        } finally {
            // Ressourcen aufräumen, wenn der Client getrennt wird oder ein Fehler auftritt
            cleanup();
        }
    }

    /**
     * Sendet eine Nachricht an den Client, sofern die Verbindung aktiv ist.
     */
    public void sendMessage(String message) {
        try {
            if (out != null && !clientSocket.isClosed()) {
                out.println(message);
                System.out.println("Nachricht an " + clientIP + " gesendet: " + message);
            } else {
                System.err.println("Kann nicht an " + clientIP + " senden - Verbindung geschlossen");
            }
        } catch (Exception e) {
            System.err.println("Fehler beim Senden an " + clientIP + ": " + e.getMessage());
        }
    }

    /**
     * Schließt alle Ressourcen und meldet den Client vom Server ab.
     */
    private void cleanup() {
        try {
            System.out.println("Cleaning up client connection: " + clientIP);

            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
            if (clientSocket != null && !clientSocket.isClosed()) {
                clientSocket.close();
            }

            // Entfernt diesen Client aus der Liste im Server
            server.removeClient(this);
            System.out.println("Client " + clientIP + " disconnected and cleaned up");

        } catch (IOException e) {
            System.err.println("Error during cleanup for " + clientIP + ": " + e.getMessage());
        }
    }

    /**
     * Gibt die IP-Adresse des Clients zurück.
     */
    public String getClientIP() {
        return clientIP;
    }

    /**
     * Prüft, ob der Client noch verbunden ist.
     */
    public boolean isConnected() {
        return clientSocket != null && !clientSocket.isClosed() && clientSocket.isConnected();
    }
}