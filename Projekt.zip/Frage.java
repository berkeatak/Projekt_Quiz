package Projekt_Quiz;

import java.util.List;

/**
 * Die Klasse Frage repräsentiert eine einzelne Quizfrage mit mehreren Antwortmöglichkeiten.
 * Sie speichert den Fragetext, die Liste der möglichen Antworten und den Index der richtigen Antwort.
 *
 * Diese Klasse wird im Rahmen eines Quiz-Projekts verwendet, um einzelne Fragen zu modellieren.
 */
public class Frage {
    // Der Text der Frage, der dem Benutzer angezeigt wird.
    private String frageText;

    // Die Liste der möglichen Antworten zu dieser Frage.
    private List<String> antwortMoeglichkeiten;

    // Der Index in der Liste 'antwortMoeglichkeiten', der die richtige Antwort angibt.
    private int richtigeAntwortIndex;

    /**
     * Konstruktor zum Erstellen einer neuen Frage.
     * @param frageText Der Text der Frage.
     * @param antwortMoeglichkeiten Die Liste der möglichen Antworten.
     * @param richtigeAntwortIndex Der Index der richtigen Antwort in der Liste.
     */
    public Frage(String frageText, List<String> antwortMoeglichkeiten, int richtigeAntwortIndex) {
        this.frageText = frageText;
        this.antwortMoeglichkeiten = antwortMoeglichkeiten;
        this.richtigeAntwortIndex = richtigeAntwortIndex;
    }

    /**
     * Gibt den Fragetext zurück.
     * @return Der Text der Frage.
     */
    public String getFrageText() {
        return frageText;
    }

    /**
     * Gibt die Liste der Antwortmöglichkeiten zurück.
     * @return Eine Liste mit allen möglichen Antworten.
     */
    public List<String> getAntwortMoeglichkeiten() {
        return antwortMoeglichkeiten;
    }

    /**
     * Überprüft, ob eine gegebene Antwort (über den Index) korrekt ist.
     * @param index Der Index der gegebenen Antwort.
     * @return true, wenn die Antwort richtig ist, sonst false.
     */
    public boolean istAntwortRichtig(int index) {
        return index == richtigeAntwortIndex;
    }

    /**
     * Gibt den Index der richtigen Antwort zurück.
     * @return Der Index der richtigen Antwort in der Liste der Antwortmöglichkeiten.
     */
    public int getRichtigeAntwortIndex() {
        return richtigeAntwortIndex;
    }
}